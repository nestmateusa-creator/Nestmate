# NextMate App

NextMate is a digital home management application designed to help homeowners organize and maintain their home information efficiently. This README provides an overview of the project, setup instructions, features, and usage guidelines.

## Table of Contents
- [Features](#features)
- [Files of interest](#files-of-interest)
- [Local development](#local-development)
- [LLM proxy server](#llm-proxy-server)
- [Usage](#usage)
- [Security notes](#security-notes)
- [Contributing](#contributing)
- [License](#license)

## Features
- User authentication with Firebase Auth
- Per-user dashboard with draggable widgets and persistent order
- Local guided chatbot with optional LLM proxy integration
- Home Health Score computed from user-supplied home data

## Files of interest
- `dashboard.html` — main control panel UI that connects to Firebase and the LLM proxy.
- `scripts/dashboard.js` — client-side logic for widgets, persistence, and chatbot.
- `firebaseconfig.js` — your project-specific Firebase config (must exist and be correct).
- `server/` — Express proxy server for LLM calls.

## Local development

1. Make sure you have Node.js (>=18) and npm installed if you plan to run the server.

2. Serve the frontend statically (the dashboard reads `firebaseconfig.js` from the repo root):

```powershell
cd "c:\Users\inves\OneDrive\Desktop\nextmate-app"
python -m http.server 8080
# then open http://localhost:8080/dashboard.html
```

3. Ensure `firebaseconfig.js` contains your Firebase project's web config.

## LLM proxy server

The `server/` folder contains a small Express app that securely proxies prompts to an LLM provider.

Quick start:

```powershell
cd "c:\Users\inves\OneDrive\Desktop\nextmate-app\server"
copy ..\.env.example .env
# Edit .env and set OPENAI_API_KEY or PROVIDER_URL; optionally set FIREBASE_ADMIN_SDK_JSON to enable ID verification and logs.
npm install
npm start
```

The server exposes `POST /api/llm` that accepts JSON `{ prompt, userId? }` and returns `{ reply }`.

Client integration:
- The dashboard defaults to `window.LLM_API_URL = 'http://localhost:3000/api/llm'`.
- Use the "Use LLM proxy" toggle in the dashboard header to enable/disable usage of the proxy.

## Usage
- Sign in with Google (Firebase Auth) when the dashboard prompts.
- Drag widgets to reorder; the order is saved per-user to Firestore.
- Use the chatbot (bottom-left) to guide data entry. When the LLM proxy is enabled, the assistant will attempt to provide richer replies and can auto-apply recognized facts into your profile when "Auto-apply replies" is enabled.

## Security notes
- Keep LLM API keys server-side in `.env`. Do not store secrets in the frontend.
- For production, restrict who can write `settings/global` in Firestore. Consider using a Cloud Function with admin privileges for toggling global flags.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for improvements.

## License
This project is licensed under the MIT License.

## Smoke harness & automated tests

There is a lightweight smoke harness for quick manual verification without Firebase or Node:

- `smoke.html` — open in a browser to preview the dashboard UI and exercise the right-hand details panel, sliders, and save flow.

Automated tests

- Unit tests use Mocha + Chai and already exist in `test/` (health score and section detection).
- A Puppeteer e2e test is provided at `test/e2e.spec.js` that opens `smoke.html` via a file:// URL and verifies panel opening, slider sync, and simple save flow.

To run tests locally you will need Node.js and npm:

```powershell
# from repo root
npm install
npm test            # run unit tests
npm run test:e2e    # run Puppeteer e2e tests
```

Note: CI/runner environments must allow Puppeteer/Chromium to run. If you want, I can add a GitHub Actions workflow to run the e2e tests in CI.

## Developer notes (local debug & persistence)

The dashboard uses a local-first persistence strategy to avoid data loss when users are not authenticated. Helpful keys and helpers:

- `localStorage` keys:
	- `nm_dashboard` — primary JSON payload for the dashboard (order, widgets, data). This is written by the dashboard UI and is the canonical local snapshot.
	- `nm_dashboard_backup` — a recent backup copy written after each save.
	- `dashboardWidgetOrder_lastUser` — last saved widget order (array) used when no authenticated user is available.

- Debug helpers available in the browser console (when `scripts/dashboard.js` is loaded):
	- `window.nm_self_test()` — creates a sample task and writes it to `nm_dashboard` (returns a Promise).
	- `renderWidgets()` — (internal) re-renders dashboard widgets from `window.userState`.
	- `updateDebugPanel(msg)` — updates the on-page debug panel with a short status message (if present).

- Quick manual checks:
	1. Open the dashboard in your browser.
	2. Open DevTools → Application → Local Storage → check the `nm_dashboard` value.
	3. Use the on-page Visible Debug panel (bottom-right) to Refresh or run Self-test.

If you'd like, I can remove the on-page polling rehydrate (currently turned into a manual Refresh) or add an authenticated sync button to push local snapshots to Firestore.#   C H A T G P T  
 #   C H A T G P T  
 