// Firebase configuration - Production NestMate Project
const firebaseConfig = {
    apiKey: "AIzaSyC7vRXVWl64DyBHywDOcRHAwm5Oij5G7yI",
    authDomain: "nestmate-167ed.firebaseapp.com",
    projectId: "nestmate-167ed",
    storageBucket: "nestmate-167ed.appspot.com",
    messagingSenderId: "865171535257",
    appId: "1:865171535257:web:nextmate-web-app",
    measurementId: "G-NEXTMATE-ANALYTICS"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
